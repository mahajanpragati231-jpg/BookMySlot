 function login() {
    let user = document.getElementById("username").value;
    let pass = document.getElementById("password").value;

    if(user === "admin" && pass === "1234") {
        window.location.href = "booking.html";
        return false;
    } else {
        document.getElementById("errorMsg").innerText = "Wrong Username or Password!";
        return false;
    }
}

function book() {
    let date = document.getElementById("date").value;
    let msg = document.getElementById("successMsg");

    if(date === "") {
        msg.innerText = "Please select a date!";
    } else {
        msg.innerText = "🎉 Booking Successful! Stay healthy & happy 😊";
    }
}